#ifndef DASH__MEMORY_H__INCLUDED
#define DASH__MEMORY_H__INCLUDED

#include <dash/memory/GlobHeapMem.h>

#endif // DASH__MEMORY_H__INCLUDED
