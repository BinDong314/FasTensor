#ifndef DASH__TEST__EQUAL_TEST_H_
#define DASH__TEST__EQUAL_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for algorithm dash::equal
 */
class EqualTest : public dash::test::TestBase {
};
#endif  // DASH__TEST__EQUAL_TEST_H_
