#ifndef DASH__TEST__DART_LOCALITY_TEST_H_
#define DASH__TEST__DART_LOCALITY_TEST_H_

#include "../TestBase.h"


/**
 * Test fixture for onesided operations provided by DART.
 */
class DARTLocalityTest : public dash::test::TestBase {
};

#endif // DASH__TEST__DART_LOCALITY_TEST_H_
