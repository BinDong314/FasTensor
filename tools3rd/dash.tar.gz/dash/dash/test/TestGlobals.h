#ifndef DASH__TEST__TEST_GLOBALS_H_
#define DASH__TEST__TEST_GLOBALS_H_

// store program arguments to pass to dash::init
class TESTENV {
public:
  static int     argc;
  static char ** argv;
};

#endif // DASH__TEST__TEST_GLOBALS_H_
