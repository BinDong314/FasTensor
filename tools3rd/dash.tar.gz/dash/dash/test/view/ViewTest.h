#ifndef DASH__TEST__VIEW_TEST_H_
#define DASH__TEST__VIEW_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for the DASH View concept
 */
class ViewTest : public dash::test::TestBase {
};

#endif // DASH__TEST__VIEW_TEST_H_
