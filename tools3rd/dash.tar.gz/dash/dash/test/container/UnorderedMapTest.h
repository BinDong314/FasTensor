#ifndef DASH__TEST__UNORDERED_MAP_TEST_H_
#define DASH__TEST__UNORDERED_MAP_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for class dash::UnorderedMap
 */
class UnorderedMapTest : public dash::test::TestBase {
};

#endif // DASH__TEST__UNORDERED_MAP_TEST_H_
