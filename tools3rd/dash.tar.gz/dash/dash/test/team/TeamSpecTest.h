#ifndef DASH__TEST__TEAM_SPEC_TEST_H_
#define DASH__TEST__TEAM_SPEC_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for class dash::TeamSpec
 */
class TeamSpecTest : public dash::test::TestBase {
protected:

  TeamSpecTest() {
  }

  virtual ~TeamSpecTest() {
  }
};

#endif // DASH__TEST__TEAM_SPEC_TEST_H_
