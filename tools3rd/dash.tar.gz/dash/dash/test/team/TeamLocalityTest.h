#ifndef DASH__TEST__TEAM_LOCALITY_TEST_H_
#define DASH__TEST__TEAM_LOCALITY_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for class dash::TeamLocality
 */
class TeamLocalityTest : public dash::test::TestBase {
};

#endif // DASH__TEST__TEAM_LOCALITY_TEST_H_
