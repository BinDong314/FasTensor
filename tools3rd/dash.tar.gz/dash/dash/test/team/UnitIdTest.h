#ifndef DASH__TEST__UNIT_ID_TEST_H__INCLUDED
#define DASH__TEST__UNIT_ID_TEST_H__INCLUDED

#include "../TestBase.h"

/**
 * Test fixture for class DASH unit id types.
 */
class UnitIdTest : public dash::test::TestBase {
protected:

  UnitIdTest() {
  }

  virtual ~UnitIdTest() {
  }
};

#endif // DASH__TEST__UNIT_ID_TEST_H__INCLUDED
