#ifndef DASH__TEST__EPOCH_SYNCHRONIZED_ALLOCATOR_TEST_H_
#define DASH__TEST__EPOCH_SYNCHRONIZED_ALLOCATOR_TEST_H_

#include "../TestBase.h"

class EpochSynchronizedAllocatorTest : public dash::test::TestBase {
};

#endif

