#ifndef DASH__TEST__CONFIG_TEST_H_
#define DASH__TEST__CONFIG_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for class dash::Config
 */
class ConfigTest : public dash::test::TestBase {
};

#endif // DASH__TEST__CONFIG_TEST_H_
