#ifndef DASH__TEST__FOR_EACH_TEST_H_
#define DASH__TEST__FOR_EACH_TEST_H_

#include "TestBase.h"

class TestPrinterTest: public dash::test::TestBase {
protected:

  TestPrinterTest() {
  }

  virtual ~TestPrinterTest() {
  }
};

#endif // DASH__TEST__FOR_EACH_TEST_H_
