#ifndef DASH__TEST__DART_TYPES_TEST_H__INCLUDED
#define DASH__TEST__DART_TYPES_TEST_H__INCLUDED

#include "../TestBase.h"


/**
 * Test fixture for class dash::DARTTypes
 */
class DARTTypesTest : public dash::test::TestBase {
};

#endif // DASH__TEST__DART_TYPES_TEST_H__INCLUDED
