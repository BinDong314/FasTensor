#ifndef DASH__TEST__DOMAIN_TEST_H_
#define DASH__TEST__DOMAIN_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for class dash::Domain
 */
class DomainTest : public dash::test::TestBase {
};

#endif // DASH__TEST__DOMAIN_TEST_H_
