#ifndef DASH__TEST__GLOBREF_TEST_H_
#define DASH__TEST__GLOBREF_TEST_H_

#include <gtest/gtest.h>

#include "../TestBase.h"


/**
 * Test fixture for global iterators
 */
class GlobIterTest: public dash::test::TestBase {
};

#endif // DASH__TEST__GLOBREF_TEST_H_
