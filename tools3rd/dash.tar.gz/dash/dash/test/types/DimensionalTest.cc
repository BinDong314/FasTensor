
#include "DimensionalTest.h"

#include <dash/Dimensional.h>

#include <array>
#include <numeric>
#include <functional>


TEST_F(DimensionalTest, DefaultConstructor)
{
}

