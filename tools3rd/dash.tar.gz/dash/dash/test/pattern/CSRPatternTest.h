#ifndef DASH__TEST__CSR_Pattern_TEST_H_
#define DASH__TEST__CSR_Pattern_TEST_H_

#include "../TestBase.h"

/**
 * Test fixture for dash::CSRPattern
 */
class CSRPatternTest : public dash::test::TestBase {
};

#endif // DASH__TEST__CSR_Pattern_TEST_H_
