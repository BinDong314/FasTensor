#ifndef DASH__TEST__CONSTEXPR_TEST_H__INCLUDED
#define DASH__TEST__CONSTEXPR_TEST_H__INCLUDED

#include "../TestBase.h"

/**
 * Test fixture for the DASH Constexpr concept
 */
class ConstexprTest : public dash::test::TestBase {
};

#endif // DASH__TEST__CONSTEXPR_TEST_H__INCLUDED
