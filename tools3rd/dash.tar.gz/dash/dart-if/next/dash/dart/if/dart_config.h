#ifndef DART__CONFIG_H
#define DART__CONFIG_H

/* DART v4.0 */

#ifdef __cplusplus
extern "C" {
#endif

#define DART_INTERFACE_ON

typedef struct
{
} dart_config_t;

#define DART_INTERFACE_OFF

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* DART__CONFIG_H */

